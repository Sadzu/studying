import java.awt.*;

public class WoodenHouse extends House implements IBehaviour{
    public WoodenHouse() {
        set_color(Color.ORANGE);
        set_name("Wood");
        set_xCoordinate((int) (Math.random() * 1920));
        set_yCoordinate((int) (Math.random() * 1080));
    }
}