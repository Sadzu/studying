public interface IBehaviour {
    
}